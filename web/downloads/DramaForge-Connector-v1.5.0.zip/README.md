# DramaForge Connector v1.5.0

이 파일은 공식 배포한 DramaForge 웹앱에서 사용자 PC의 Codex CLI에 접근하도록 돕는 **로컬 프로그램**입니다.

## 사전 요구
- Node.js 20 이상 (`node --version` 명령으로 확인)
- OpenAI Codex CLI 설치 및 ChatGPT 계정 로그인 (연결창에서 로그인 가능)
- 파일을 받은 웹사이트가 신뢰할 수 있는 서비스인지 확인

## 실행
1. 이 ZIP을 사용자 PC의 별도 폴더에 압축 해제합니다.
2. Windows는 `run-windows.cmd`를, macOS/Linux는 터미널에서 `sh run-unix.sh`를 실행합니다.
3. 브라우저 주소에서 사이트 **출처만** 입력합니다. 예: `https://dramaforge.example` (경로 불필요).
4. 터미널에 표시된 임의 연결 코드를 브라우저의 AI 연결창에 입력합니다.
5. 프로그램 종료는 터미널에서 Ctrl+C 입니다.

### 다른 실행 방법
`npm run bridge -- --origin https://배포도메인`을 실행할 수 있습니다.

### 보안 및 데이터 범위
- 브리지는 127.0.0.1:7331 에만 바인딩하고, 등록된 사이트 Origin과 연결 토큰을 검증합니다.
- 임의 셸 명령 실행 요청은 허용하지 않습니다. 프로젝트 파일을 읽고 쓰는 공개 HTTP API도 없습니다.
- 대본 내용은 *명시적으로 AI 작업을 요청할 때* PC의 Codex CLI를 통해 OpenAI로 전송될 수 있습니다.
- 웹앱의 작품 데이터는 브라우저에 저장합니다. Vercel은 대본을 AI 요청 중계 서버로 받지 않습니다.
- 외부 Codex CLI 설치, 로그인, 운영체제별 실행 검증은 사용자 PC에서 확인해야 합니다.

원본: DramaForge-v1.5.0 GitHub 배포 소스의 `bridge/` 디렉터리.
