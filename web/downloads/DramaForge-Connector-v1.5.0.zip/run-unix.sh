#!/bin/sh
set -eu
cd "$(dirname "$0")"
printf 'DramaForge v1.5.0 Local Connector\n'
printf 'Enter your DramaForge website origin (https://...): '
IFS= read -r DF_ORIGIN
[ -n "$DF_ORIGIN" ] || { echo 'Website origin is required'; exit 1; }
node bridge/server.mjs --origin "$DF_ORIGIN"
