@echo off
cd /d "%~dp0"
echo DramaForge v1.5.0 Local Connector
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 20 or later is required.
  pause
  exit /b 1
)
set /p DF_ORIGIN=Enter your DramaForge website origin (https://...): 
if "%DF_ORIGIN%"=="" (
  echo Website origin is required.
  pause
  exit /b 1
)
npm run bridge -- --origin "%DF_ORIGIN%"
pause
